# SK Cinematic Portfolio — Production Final

Included:
- Cinematic eye + SK logo reveal
- Modal-based project/service navigation (no unwanted anchor jumping)
- Visible AI chatbot
- Supabase-backed contact enquiries
- Authenticated `/admin` login using Supabase Auth
- Admin enquiries view and site settings
- Responsive mobile refinements
- Clean deployment package (no nested duplicate project)

## Vercel environment variables
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
- OPENAI_API_KEY
- OPENAI_MODEL (optional)

## Supabase
1. Run `supabase-schema.sql` in Supabase SQL Editor.
2. In Supabase Authentication, create your admin user (email/password).
3. Add the Supabase URL and publishable key to Vercel.
4. Add OPENAI_API_KEY in Vercel for live chatbot replies.
5. Redeploy after adding environment variables.

The OpenAI key must remain server-side. Never prefix it with NEXT_PUBLIC_.
