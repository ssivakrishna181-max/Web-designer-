"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase-browser";

type Project = { id: string; title: string; category: string; description: string; published: boolean };
type Enquiry = { id: string; name: string; email: string; message: string; status: string; created_at?: string };

const starterProjects: Project[] = [
  { id: "fitzone", title: "FITZONE", category: "Brand Identity", description: "Gym & fitness visual identity", published: true },
  { id: "royal", title: "ROYAL", category: "Luxury Branding", description: "Premium luxury brand system", published: true },
  { id: "music", title: "MUSIC FESTIVAL", category: "Poster Design", description: "Festival campaign artwork", published: true },
  { id: "nature", title: "NATURE", category: "Packaging", description: "Organic store identity", published: true },
  { id: "coffee", title: "COFFEE HOUSE", category: "Brand Design", description: "Cafe branding and campaign", published: true },
  { id: "travel", title: "TRAVEL", category: "Social Creative", description: "Travel campaign visuals", published: true },
];

const emptySettings = {
  name: "Siva Krishna",
  title: "Graphic Designer & Visual Creator",
  email: "",
  whatsapp: "",
  location: "Hyderabad, Telangana, India",
  availability: "Available for selected projects",
  bio: "I help businesses and individuals stand out with creative, modern and impactful designs.",
};

export default function AdminPage() {
  const [tab, setTab] = useState("dashboard");
  const [projects, setProjects] = useState<Project[]>(starterProjects);
  const [settings, setSettings] = useState(emptySettings);
  const [message, setMessage] = useState("");
  const [supabaseReady, setSupabaseReady] = useState(false);
  const [session, setSession] = useState<any>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);

  const supabase = useMemo(() => createClient(), []);
  useEffect(() => {
    supabase.auth.getSession().then(({data}:any)=>{setSession(data?.session ?? null);setAuthChecked(true)});
    const {data}:any=supabase.auth.onAuthStateChange((_event:any,next:any)=>setSession(next));
    return ()=>data?.subscription?.unsubscribe?.();
  },[supabase]);

  useEffect(() => {
    const stored = window.localStorage.getItem("sk_admin_projects");
    const storedSettings = window.localStorage.getItem("sk_admin_settings");
    if (stored) setProjects(JSON.parse(stored));
    if (storedSettings) setSettings({ ...emptySettings, ...JSON.parse(storedSettings) });

    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
    setSupabaseReady(Boolean(url && key));

    if (url && key) {
      supabase.from("site_settings").select("key,value").then(({ data }: { data: any[] | null }) => {
        if (!data?.length) return;
        const remote = Object.fromEntries(data.map((row: any) => [row.key, typeof row.value === "string" ? row.value.replace(/^\"|\"$/g, "") : row.value]));
        setSettings((current) => ({ ...current, ...remote }));
      });
    }
  }, [supabase]);

  const saveLocal = () => {
    window.localStorage.setItem("sk_admin_projects", JSON.stringify(projects));
    window.localStorage.setItem("sk_admin_settings", JSON.stringify(settings));
    setMessage("Saved in this browser. Add Supabase environment variables for shared production data.");
  };

  const saveSettings = async () => {
    window.localStorage.setItem("sk_admin_settings", JSON.stringify(settings));
    if (supabaseReady) {
      const rows = Object.entries(settings).map(([key, value]) => ({ key, value: JSON.stringify(value) }));
      const { error } = await supabase.from("site_settings").upsert(rows, { onConflict: "key" });
      setMessage(error ? error.message : "Site settings saved to Supabase.");
    } else {
      setMessage("Settings saved locally. Connect Supabase in Vercel to make them shared and persistent.");
    }
  };

  useEffect(()=>{ if(tab==="messages" && session) supabase.from("enquiries").select("*").order("created_at",{ascending:false}).then(({data}:any)=>setEnquiries(data??[])); },[tab,session,supabase]);
  const login=async(e:React.FormEvent)=>{e.preventDefault();const {error}=await supabase.auth.signInWithPassword({email:loginEmail,password:loginPassword});if(error)setMessage(error.message)};
  const logout=async()=>{await supabase.auth.signOut();setSession(null)};
  const published = projects.filter((p) => p.published).length;

  if(!authChecked) return <div className="admin-auth"><div className="admin-auth-card">Checking admin access…</div></div>;
  if(!session) return <div className="admin-auth"><form onSubmit={login} className="admin-auth-card"><img src="/logo.png" alt="SK"/><p className="eyebrow">SECURE CONTROL ROOM</p><h1>Admin Login</h1><p>Sign in with the Supabase admin account for this portfolio.</p><input type="email" required placeholder="Admin email" value={loginEmail} onChange={e=>setLoginEmail(e.target.value)}/><input type="password" required placeholder="Password" value={loginPassword} onChange={e=>setLoginPassword(e.target.value)}/><button className="primary-btn">SIGN IN →</button>{message&&<small>{message}</small>}<Link href="/">← Back to portfolio</Link></form></div>;

  return (
    <div className="min-h-screen bg-[#02050b] text-white">
      <div className="mx-auto flex min-h-screen max-w-[1500px]">
        <aside className="hidden w-72 shrink-0 border-r border-white/10 bg-[#030913] p-6 lg:block">
          <Link href="/" className="flex items-center gap-3 border-b border-white/10 pb-6">
            <img src="/logo.png" alt="SK" className="h-12 w-12 rounded-full" />
            <span><b className="block text-cyan-300">SK</b><small className="tracking-[.25em] text-white/60">ADMIN</small></span>
          </Link>
          <nav className="mt-8 space-y-2">
            {[["dashboard","Dashboard"],["projects","Projects"],["settings","Site Settings"],["messages","Enquiries"],["appearance","Appearance"]].map(([id,label]) => (
              <button key={id} onClick={() => setTab(id)} className={`w-full rounded-xl px-4 py-3 text-left text-sm font-bold transition ${tab === id ? "bg-blue-600/20 text-cyan-300 ring-1 ring-cyan-300/20" : "text-white/60 hover:bg-white/5 hover:text-white"}`}>{label}</button>
            ))}
          </nav>
          <div className="mt-8 rounded-2xl border border-white/10 bg-black/20 p-4 text-xs text-white/45">
            <p className="font-bold text-white/80">Backend status</p>
            <p className="mt-2">{supabaseReady ? "● Supabase connected" : "● Local mode"}</p>
          </div>
          <Link href="/" className="mt-4 block rounded-xl border border-white/10 px-4 py-3 text-center text-xs font-bold text-white/70 hover:text-white">← View public site</Link>
        </aside>

        <main className="min-w-0 flex-1 p-5 sm:p-8">
          <header className="mb-8 flex flex-wrap items-center justify-between gap-4">
            <div><p className="text-[10px] font-black tracking-[.35em] text-cyan-300">SK DESIGNER / CONTROL ROOM</p><h1 className="mt-2 text-3xl font-black sm:text-4xl">{tab === "dashboard" ? "Dashboard" : tab === "projects" ? "Portfolio Projects" : tab === "settings" ? "Site Settings" : tab === "messages" ? "Client Enquiries" : "Appearance"}</h1></div>
            <div className="flex gap-2"><Link href="/" className="rounded-full border border-white/10 px-4 py-2 text-xs font-bold text-white/70">Open site</Link><button onClick={logout} className="rounded-full border border-white/10 px-4 py-2 text-xs font-bold text-white/70">Logout</button><button onClick={saveLocal} className="rounded-full bg-gradient-to-r from-blue-600 to-cyan-400 px-4 py-2 text-xs font-black text-[#021020]">Save</button></div>
          </header>

          {message && <div className="mb-5 rounded-xl border border-cyan-300/20 bg-cyan-300/5 px-4 py-3 text-xs text-cyan-100">{message}</div>}

          {tab === "dashboard" && <>
            <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {[['Published Projects', published],['Total Projects', projects.length],['Services', 6],['Theme', 'Cinematic']].map(([label,value]) => <div key={String(label)} className="rounded-2xl border border-white/10 bg-[#050b14] p-5"><p className="text-xs text-white/45">{label}</p><p className="mt-3 text-2xl font-black text-white">{value}</p></div>)}
            </section>
            <section className="mt-5 grid gap-5 xl:grid-cols-[1.5fr_1fr]">
              <div className="rounded-2xl border border-white/10 bg-[#050b14] p-6"><p className="text-xs font-black tracking-[.3em] text-blue-400">QUICK ACTIONS</p><div className="mt-5 grid gap-3 sm:grid-cols-2"><button onClick={() => setTab("projects")} className="rounded-xl bg-blue-600/15 p-5 text-left font-bold text-cyan-200">＋ Manage portfolio<br/><small className="font-normal text-white/40">Add, publish or remove work</small></button><button onClick={() => setTab("settings")} className="rounded-xl bg-cyan-400/10 p-5 text-left font-bold text-cyan-200">✎ Edit profile<br/><small className="font-normal text-white/40">Name, bio and contact details</small></button></div></div>
              <div className="rounded-2xl border border-white/10 bg-[#050b14] p-6"><p className="text-xs font-black tracking-[.3em] text-blue-400">SYSTEM</p><p className="mt-5 text-sm text-white/70">The cinematic reference theme is the public-facing design. This control room is intentionally dark and compact so your content remains the focus.</p><p className="mt-4 text-xs text-white/40">{supabaseReady ? "Production database connected." : "Local mode: connect Supabase to persist changes across devices."}</p></div>
            </section>
          </>}

          {tab === "projects" && <section className="space-y-3">{projects.map((project) => <article key={project.id} className="rounded-2xl border border-white/10 bg-[#050b14] p-5"><div className="flex flex-wrap items-center justify-between gap-4"><div><h2 className="font-black">{project.title}</h2><p className="mt-1 text-xs text-cyan-300">{project.category}</p><p className="mt-2 text-xs text-white/45">{project.description}</p></div><div className="flex items-center gap-2"><span className={`rounded-full px-3 py-1 text-[10px] font-bold ${project.published ? "bg-emerald-400/10 text-emerald-300" : "bg-white/5 text-white/40"}`}>{project.published ? "PUBLISHED" : "DRAFT"}</span><button onClick={() => setProjects(ps => ps.map(p => p.id === project.id ? { ...p, published: !p.published } : p))} className="rounded-lg border border-white/10 px-3 py-2 text-xs">{project.published ? "Unpublish" : "Publish"}</button><button onClick={() => setProjects(ps => ps.filter(p => p.id !== project.id))} className="rounded-lg border border-red-400/20 px-3 py-2 text-xs text-red-300">Delete</button></div></div></article>)}</section>}

          {tab === "settings" && <section className="rounded-2xl border border-white/10 bg-[#050b14] p-6"><div className="grid gap-4 md:grid-cols-2">{Object.entries(settings).map(([key,value]) => <label key={key} className="text-xs font-bold text-white/50">{key.replaceAll("_", " ").toUpperCase()}<input value={String(value)} onChange={e => setSettings(s => ({ ...s, [key]: e.target.value }))} className="mt-2 w-full rounded-xl border border-white/10 bg-black/30 p-3 text-sm text-white outline-none focus:border-cyan-300/40" /></label>)}</div><button onClick={saveSettings} className="mt-6 rounded-full bg-gradient-to-r from-blue-600 to-cyan-400 px-6 py-3 text-sm font-black text-[#021020]">Save Site Settings</button></section>}

          {tab === "messages" && <section className="space-y-3">{enquiries.length===0?<div className="rounded-2xl border border-white/10 bg-[#050b14] p-8 text-center"><div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-blue-500/10 text-2xl">✉</div><h2 className="mt-4 text-xl font-black">No enquiries yet</h2><p className="mt-2 text-sm text-white/45">New contact-form messages will appear here.</p></div>:enquiries.map(q=><article key={q.id} className="rounded-2xl border border-white/10 bg-[#050b14] p-5"><div className="flex justify-between gap-4"><div><b>{q.name}</b><a className="ml-3 text-xs text-cyan-300" href={`mailto:${q.email}`}>{q.email}</a><p className="mt-3 text-sm text-white/65">{q.message}</p><small className="mt-3 block text-white/30">{q.created_at?new Date(q.created_at).toLocaleString():""}</small></div><span className="h-fit rounded-full bg-cyan-400/10 px-3 py-1 text-[10px] text-cyan-300">{q.status||"new"}</span></div></article>)}</section>}

          {tab === "appearance" && <section className="rounded-2xl border border-white/10 bg-[#050b14] p-6"><p className="text-xs font-black tracking-[.3em] text-cyan-300">ACTIVE THEME</p><div className="mt-5 rounded-2xl border border-blue-400/20 bg-gradient-to-br from-[#02050b] via-[#06132b] to-[#090315] p-8"><h2 className="text-3xl font-black">Cinematic Neon</h2><p className="mt-2 max-w-xl text-sm text-white/50">Dark navy/black interface, electric blue accents, cyan glow and the blue eye + multicolor paint hero composition.</p><div className="mt-6 flex gap-3"><span className="h-10 w-10 rounded-full bg-[#02050b] ring-1 ring-white/10"/><span className="h-10 w-10 rounded-full bg-[#087dff]"/><span className="h-10 w-10 rounded-full bg-[#19cfff]"/><span className="h-10 w-10 rounded-full bg-[#e91e9b]"/><span className="h-10 w-10 rounded-full bg-[#ff7a18]"/></div></div></section>}

          <p className="mt-8 text-center text-[10px] text-white/25">SK Designer Admin Panel · {supabaseReady ? "Supabase connected" : "Local browser mode"}</p>
        </main>
      </div>
    </div>
  );
}
