"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import { ContentModal } from "./ContentModal";

const projects: [string,string,string,string,string][]=[
 ["FITZONE","GYM & FITNESS","F","project-blue","Fitness brand identity, logo system, social creatives and promotional artwork."],
 ["ROYAL","LUXURY BRAND","R","project-gold","Luxury brand identity with premium gold-led visual direction and campaign graphics."],
 ["MUSIC","FESTIVAL","♫","project-purple","Music festival posters, event graphics, social media creatives and promotional visuals."],
 ["NATURE","ORGANIC STORE","◒","project-green","Organic retail identity, packaging direction, promotional graphics and social content."],
 ["COFFEE","HOUSE","☕","project-coffee","Coffee-house branding, menu graphics, campaign artwork and social media design."],
 ["TRAVEL","EXPLORE THE WORLD","△","project-travel","Travel campaign identity, destination graphics and digital promotional creatives."]
];

export function Work(){
 const [selected,setSelected]=useState<typeof projects[number]|null>(null);
 const [allOpen,setAllOpen]=useState(false);
 return <>
  <section id="work" className="dark-section work-section">
   <div className="work-wrap">
    <div className="work-head"><div><p className="eyebrow">MY WORK</p><h2>Featured Projects</h2></div><button className="outline-btn" type="button" onClick={()=>setAllOpen(true)}>VIEW ALL</button></div>
    <div className="project-grid">
     {projects.map((p)=><motion.button type="button" key={p[0]} className={`project-card ${p[3]}`} whileHover={{y:-5,scale:1.015}} whileTap={{scale:.98}} onClick={()=>setSelected(p)}>
      <div className="project-mark">{p[2]}</div><strong>{p[0]}</strong><span>{p[1]}</span><small className="project-open">VIEW PROJECT →</small>
     </motion.button>)}
    </div>
   </div>
  </section>
  <ContentModal open={allOpen} onClose={()=>setAllOpen(false)} eyebrow="PORTFOLIO" title="All Projects">
   <div className="modal-project-list">{projects.map((p)=><button type="button" key={p[0]} onClick={()=>{setAllOpen(false);setSelected(p)}}><span className="modal-project-mark">{p[2]}</span><span><b>{p[0]}</b><small>{p[1]}</small></span><i>OPEN →</i></button>)}</div>
  </ContentModal>
  <ContentModal open={!!selected} onClose={()=>setSelected(null)} eyebrow="FEATURED PROJECT" title={selected?.[0] ?? "Project"}>
   {selected && <div className={`modal-project-hero ${selected[3]}`}><div className="modal-project-big-mark">{selected[2]}</div><div><b>{selected[1]}</b><p>{selected[4]}</p><button className="primary-btn" type="button" onClick={()=>setSelected(null)}>BACK TO PORTFOLIO <span>→</span></button></div></div>}
  </ContentModal>
 </>;
}
