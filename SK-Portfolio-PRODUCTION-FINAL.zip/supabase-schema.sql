-- Run this once in Supabase SQL Editor.
create table if not exists public.site_settings (
  key text primary key,
  value jsonb not null
);
create table if not exists public.enquiries (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  message text not null,
  status text not null default 'new',
  created_at timestamptz not null default now()
);
create table if not exists public.projects (
  id text primary key,
  title text not null,
  category text not null,
  description text not null default '',
  image_url text,
  published boolean not null default false,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

alter table public.site_settings enable row level security;
alter table public.enquiries enable row level security;
alter table public.projects enable row level security;

drop policy if exists "public read settings" on public.site_settings;
create policy "public read settings" on public.site_settings for select using (true);
drop policy if exists "public read published projects" on public.projects;
create policy "public read published projects" on public.projects for select using (published = true);
drop policy if exists "public submit enquiries" on public.enquiries;
create policy "public submit enquiries" on public.enquiries for insert with check (true);

drop policy if exists "admin settings all" on public.site_settings;
create policy "admin settings all" on public.site_settings for all to authenticated using (true) with check (true);
drop policy if exists "admin projects all" on public.projects;
create policy "admin projects all" on public.projects for all to authenticated using (true) with check (true);
drop policy if exists "admin enquiries read" on public.enquiries;
create policy "admin enquiries read" on public.enquiries for select to authenticated using (true);
drop policy if exists "admin enquiries update" on public.enquiries;
create policy "admin enquiries update" on public.enquiries for update to authenticated using (true) with check (true);
